package ctr;

/**
 * @author László Hágó
 * @version 1.0
 * @since 2016-09-06
 */
public class Person
{
    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String passWord;
    private int role;

    public Person(String firstName, String lastName, String email, String passWord, int role)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.passWord = passWord;
        this.role = role;
    }

    public Person(Long id, String firstName, String lastName, String email, String passWord, int role)
    {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.passWord = passWord;
        this.role = role;
    }
}
