/**
 * @author László Hágó
 * @version 1.0
 * @since 2016-09-06
 */
public class Test
{
}
